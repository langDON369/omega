<script src="./index.js"></script>
import totalAmount from './index.js';

// Using the imported value
console.log(totalAmount);
document.getElementById("amount").innerHTML = totalAmount;