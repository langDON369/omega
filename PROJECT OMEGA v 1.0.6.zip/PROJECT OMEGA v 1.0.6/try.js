const fullNameInput = document.querySelector('.contactForm input[name=""]');
const emailInput = document.querySelector('.contactForm input[name=""]');
const messageInput = document.querySelector('.contactForm textarea');
const form = document.querySelector('.contactForm form');

form.addEventListener('submit', function(event) {
  event.preventDefault();

  const fullName = fullNameInput.value;
  const email = emailInput.value;
  const message = messageInput.value;

  const encodedMessage = encodeURIComponent(`Full Name: ${fullName}\nEmail: ${email}\nMessage: ${message}`);
  const whatsappLink = `https://wa.me/9072732334/?text=${encodedMessage}`;
  window.open(whatsappLink, '_blank');
});
